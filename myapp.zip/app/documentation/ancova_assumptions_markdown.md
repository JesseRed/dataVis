---
title: "ANCOVA assumptions"
output:
  html_document:
    toc: yes
pagetitle: ANCOVA assumptions
---


# ANCOVA Assumptions
--------------------------------------

ANCOVA has the same assumptions as ANOVA except that there are two important additonal considerations: 
1. independence of the covariate and treatment effect
1. homogeneity of regression slopes


-------------------------------




******************************


