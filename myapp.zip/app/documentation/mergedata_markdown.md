# merge Data

## In Short 
1. the data that should be merged must be preprocessed in different directories
1. choose these directories and an new directiory with the combinded data will be created
1. merging means that new subjects will be added ... no other parameter will be merged

--------------

## In Long




