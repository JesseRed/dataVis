---
title: "Comp_Stats_Trials"
output:
  html_document:
    toc: yes
pagetitle: Comp_Stats_Trials
---


# Comp_Stats_Trials
--------------------------------------

Show results of the statisitical estimation of the comparison between trials for one group

******************************


