---
title: "Options Regions"
output:
  html_document:
    toc: yes
pagetitle: Options Regions
---


# Options Regions
--------------------------------------

The regions can be altered in their sequence, this was initially implemented for the circle plot
also the names can be altered
The altered sequence and names are written in the data directory ...
This means all data will be overwritten particularly the data Matrix will be rewritten


-------------------------------




******************************


