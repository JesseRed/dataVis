---
title: "Comp_Diff_Stats"
output:
  html_document:
    toc: yes
pagetitle: Comp_Diff_Stats
---


# Comp_Diff_Stats
--------------------------------------

Show results of the statisitical estimation of the comparison between groups for the intra group trial differences

******************************


