---
title: "Comp_Groups_Stats"
output:
  html_document:
    toc: yes
pagetitle: Comp_Groups_Stats
---


# Comp_Group_Stats
--------------------------------------

Show results of the statisitical estimation of the comparison between groups for one trial

******************************


